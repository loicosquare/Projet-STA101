# This project has a goal to automatize all procedures for project into dehon group.
